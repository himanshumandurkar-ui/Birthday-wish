const $=id=>document.getElementById(id);
const keys=[
 ["name","Friend's name","text"],["birthday","Birth date","date"],["accent","Main colour","color"],
 ["heroEyebrow","Small line above title","text"],["heroTitle","Main title","text"],["heroLine","Line under title","text"],
 ["introA","Intro heading, line 1","text"],["introB","Intro heading, line 2","text"],["introText","Intro paragraph","textarea"],
 ["bubbleTitle","Bubble section title","text"],["bubbleSub","Bubble section text","text"],
 ["footerTitle","Footer title","text"],["footerText","Footer text","text"],["footerStrong","Footer wish","text"],["footerSmall","Footer small line","text"]
];
let profiles=[],defaultSlug="",current="",data={},photos=[];
function message(t,bad=false){$("status").textContent=t;$("status").style.display="block";$("status").style.background=bad?"#a3122f":"#3f2433";}
async function api(url,body){const r=await fetch(url,{method:body?"POST":"GET",headers:body?{"Content-Type":"application/json"}:{},body:body?JSON.stringify(body):undefined});const j=await r.json();if(!r.ok)throw Error(j.error||"Request failed");return j;}
async function boot(){
 const auth=await api("/api/admin/login"); if(!auth.authenticated){$("login").hidden=false;$("app").hidden=true;return;}
 $("login").hidden=true;$("app").hidden=false;await loadAll();
}
async function loadAll(){
 const j=await api("/api/admin/data");profiles=j.profiles;defaultSlug=j.defaultSlug;
 $("profile").innerHTML="";profiles.forEach(p=>{const o=document.createElement("option");o.value=p.slug;o.textContent=(p.data.name||p.slug)+" ("+p.slug+")"+(p.slug===defaultSlug?" · default": "");$("profile").append(o);});
 current=current&&profiles.some(p=>p.slug===current)?current:(defaultSlug||profiles[0]?.slug);
 $("profile").value=current;loadProfile();
}
function loadProfile(){
 const p=profiles.find(x=>x.slug===current);if(!p)return;data=p.data||{};photos=Array.isArray(data.photos)?data.photos.map(x=>({...x})):[]; 
 keys.forEach(([k,label,type])=>{const el=$(k);if(el)el.value=data[k]??(type==="color"?"#bd6687":"");});
 $("letter").value=data.letter||"";$("showLetterBubble").checked=data.showLetterBubble!==false;
 $("share").textContent=`Share link: ${location.origin}/?for=${current}`;renderPhotos();
}
function buildFields(){keys.forEach(([k,label,type])=>{const wrap=document.createElement("div");wrap.className="field"+(["introText"].includes(k)?" full":"");const l=document.createElement("label");l.textContent=label;const el=document.createElement(type==="textarea"?"textarea":"input");if(type!=="textarea")el.type=type;el.id=k;wrap.append(l,el);$("fields").append(wrap);});}
function renderPhotos(){
 const box=$("photos");box.innerHTML="";
 if(!photos.length){box.textContent="No photos added yet.";return;}
 photos.forEach((p,i)=>{const row=document.createElement("div");row.className="photo";const img=document.createElement("img");img.src=p.src;const cap=document.createElement("input");cap.value=p.caption||"";cap.placeholder="Photo caption";cap.oninput=()=>p.caption=cap.value;
 const btn=(txt,fn,cl="alt")=>{const b=document.createElement("button");b.className=cl;b.type="button";b.textContent=txt;b.onclick=fn;return b;};
 row.append(img,cap,btn("↑",()=>{if(i){[photos[i-1],photos[i]]=[photos[i],photos[i-1]];renderPhotos();}}),btn("↓",()=>{if(i<photos.length-1){[photos[i+1],photos[i]]=[photos[i],photos[i+1]];renderPhotos();}}),btn("Remove",()=>{photos.splice(i,1);renderPhotos();},"danger"));box.append(row);});
}
async function upload(file){
 const base64=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result).split(",")[1]);r.onerror=reject;r.readAsDataURL(file);});
 return api("/api/admin/upload",{fileBase64:base64,contentType:file.type});
}
$("loginForm").onsubmit=async e=>{e.preventDefault();$("loginMsg").textContent="";try{await api("/api/admin/login",{password:$("password").value});$("password").value="";await boot();}catch(err){$("loginMsg").textContent=err.message;}};
$("logout").onclick=async()=>{await fetch("/api/admin/logout",{method:"POST"});location.reload();};
$("profile").onchange=()=>{current=$("profile").value;loadProfile();};
$("photoFiles").onchange=async e=>{const files=[...e.target.files];e.target.value="";for(let i=0;i<files.length;i++){try{message(`Uploading ${i+1}/${files.length}…`);const j=await upload(files[i]);photos.push({src:j.src,caption:""});}catch(err){message(err.message,true);}}renderPhotos();message("Uploads complete. Press Save all changes to attach them to this page.");};
$("save").onclick=async()=>{const d={};keys.forEach(([k])=>d[k]=$(k).value);d.showLetterBubble=$("showLetterBubble").checked;d.letter=$("letter").value;d.photos=photos;try{$("save").disabled=true;await api("/api/admin/data",{action:"save",slug:current,data:d});message("Saved. Refresh the birthday page to see your changes.");}catch(e){message(e.message,true);}finally{$("save").disabled=false;}};
$("makeDefault").onclick=async()=>{try{await api("/api/admin/data",{action:"default",slug:current});await loadAll();message("Default page updated.");}catch(e){message(e.message,true);}};
$("newProfile").onclick=async()=>{const name=prompt("Name of the new person?");if(!name)return;try{const j=await api("/api/admin/data",{action:"create",name,copyFrom:current});current=j.slug;await loadAll();message("New birthday page created.");}catch(e){message(e.message,true);}};
$("deleteProfile").onclick=async()=>{if(!confirm("Delete this birthday page? This cannot be undone."))return;try{await api("/api/admin/data",{action:"delete",slug:current});current="";await loadAll();message("Page deleted.");}catch(e){message(e.message,true);}};
buildFields();boot().catch(e=>{ $("loginMsg").textContent=e.message; });